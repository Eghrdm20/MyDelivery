import { useEffect, useMemo, useState } from "react"

export type OrderStatus = "pending" | "in_progress" | "delivered" | "cancelled"
export type OrderType = "food" | "groceries" | "pharmacy" | "documents" | "other"
export type PaymentMethod = "cash" | "card" | "wallet"

export interface LocationPoint {
  address: string
  lat?: number
  lng?: number
}

export interface StatusEvent {
  status: OrderStatus
  label: string
  timestamp: string
}

export interface Order {
  id: string
  type: OrderType
  pickupAddress: string
  deliveryAddress: string
  packageDetails: string
  price: number
  estimatedTime: number
  distanceKm: number
  status: OrderStatus
  createdAt: string
  scheduledFor?: string
  paymentMethod: PaymentMethod
  customerName: string
  customerPhone: string
  deliveryPartner?: string
  partnerPhone?: string
  partnerId?: string
  pickupLocation?: LocationPoint
  deliveryLocation?: LocationPoint
  statusHistory: StatusEvent[]
  rating?: number
  notes?: string
}

export interface DeliveryQuote {
  type: OrderType
  price: number
  estimatedTime: number
  distanceKm: number
  serviceFee: number
  basePrice: number
}

export interface UserProfile {
  name: string
  phone: string
  email: string
  city: string
  memberSince: string
  rating: number
  verified: boolean
  preferredPayment: PaymentMethod
  pushNotifications: boolean
  smsUpdates: boolean
}

const STORAGE_KEY = "deliveryfast_orders_v2"
const LEGACY_STORAGE_KEY = "deliveryfast_orders"
const PROFILE_KEY = "deliveryfast_profile_v2"
const PARTNER_STATE_KEY = "deliveryfast_partner_state_v2"
const ORDER_PREFIX = "DF"

export const ORDER_TYPE_INFO: Record<OrderType, { name: string; icon: string; basePrice: number; baseTime: number }> = {
  food: { name: "Food & Restaurants", icon: "🍕", basePrice: 15, baseTime: 25 },
  groceries: { name: "Groceries", icon: "🛒", basePrice: 20, baseTime: 40 },
  pharmacy: { name: "Pharmacy", icon: "💊", basePrice: 12, baseTime: 20 },
  documents: { name: "Documents", icon: "📄", basePrice: 10, baseTime: 30 },
  other: { name: "Other Package", icon: "📦", basePrice: 18, baseTime: 35 },
}

export const DEFAULT_PROFILE: UserProfile = {
  name: "Youssef Benali",
  phone: "+212 6 12 34 56 78",
  email: "youssef.benali@email.com",
  city: "Casablanca, Morocco",
  memberSince: "Jan 2024",
  rating: 4.9,
  verified: true,
  preferredPayment: "cash",
  pushNotifications: true,
  smsUpdates: true,
}

const nowMinusMinutes = (minutes: number) => new Date(Date.now() - minutes * 60 * 1000).toISOString()

const demoOrders: Order[] = [
  {
    id: "DF001",
    type: "food",
    pickupAddress: "Pizza Hut, Centre Ville",
    deliveryAddress: "Apartment, Medina",
    packageDetails: "Large pizza, drinks, call customer when arriving.",
    price: 22,
    estimatedTime: 30,
    distanceKm: 3.4,
    status: "in_progress",
    createdAt: nowMinusMinutes(38),
    paymentMethod: "cash",
    customerName: DEFAULT_PROFILE.name,
    customerPhone: DEFAULT_PROFILE.phone,
    deliveryPartner: "Amine El Fassi",
    partnerPhone: "+212 6 77 44 21 10",
    partnerId: "partner-demo",
    statusHistory: [
      { status: "pending", label: "Order placed", timestamp: nowMinusMinutes(38) },
      { status: "in_progress", label: "Partner accepted and is on the way", timestamp: nowMinusMinutes(21) },
    ],
  },
  {
    id: "DF002",
    type: "groceries",
    pickupAddress: "Carrefour, Twin Center",
    deliveryAddress: "Villa, Ain Diab",
    packageDetails: "Groceries - fruits, vegetables, and bottled water.",
    price: 25,
    estimatedTime: 45,
    distanceKm: 5.7,
    status: "delivered",
    createdAt: nowMinusMinutes(240),
    paymentMethod: "card",
    customerName: DEFAULT_PROFILE.name,
    customerPhone: DEFAULT_PROFILE.phone,
    deliveryPartner: "Fatima Zahra",
    partnerPhone: "+212 6 81 23 45 67",
    partnerId: "partner-fatima",
    statusHistory: [
      { status: "pending", label: "Order placed", timestamp: nowMinusMinutes(240) },
      { status: "in_progress", label: "Partner picked up your package", timestamp: nowMinusMinutes(218) },
      { status: "delivered", label: "Delivered successfully", timestamp: nowMinusMinutes(190) },
    ],
    rating: 5,
  },
  {
    id: "DF003",
    type: "pharmacy",
    pickupAddress: "Pharmacie Centrale, Hassan",
    deliveryAddress: "Apartment, Agdal",
    packageDetails: "Medicine and health products. Keep the bag sealed.",
    price: 14,
    estimatedTime: 25,
    distanceKm: 2.2,
    status: "pending",
    createdAt: nowMinusMinutes(10),
    paymentMethod: "cash",
    customerName: DEFAULT_PROFILE.name,
    customerPhone: DEFAULT_PROFILE.phone,
    statusHistory: [{ status: "pending", label: "Waiting for a delivery partner", timestamp: nowMinusMinutes(10) }],
  },
]

const safeParse = <T,>(value: string | null): T | null => {
  if (!value) return null
  try {
    return JSON.parse(value) as T
  } catch {
    return null
  }
}

const hashText = (value: string): number => {
  return value.split("").reduce((total, char) => total + char.charCodeAt(0), 0)
}

export const estimateDeliveryQuote = (
  type: OrderType,
  pickupAddress: string,
  deliveryAddress: string,
  packageDetails = "",
): DeliveryQuote => {
  const info = ORDER_TYPE_INFO[type]
  const distanceKm = Number(((hashText(pickupAddress + deliveryAddress) % 75) / 10 + 1.2).toFixed(1))
  const detailFee = packageDetails.length > 80 ? 4 : packageDetails.length > 35 ? 2 : 0
  const serviceFee = Math.max(3, Math.ceil(distanceKm * 1.7) + detailFee)
  const price = info.basePrice + serviceFee
  const estimatedTime = info.baseTime + Math.ceil(distanceKm * 3)

  return {
    type,
    price,
    estimatedTime,
    distanceKm,
    serviceFee,
    basePrice: info.basePrice,
  }
}

const normalizeOrder = (order: Partial<Order>): Order => {
  const type = order.type ?? "other"
  const quote = estimateDeliveryQuote(
    type,
    order.pickupAddress ?? "Unknown pickup",
    order.deliveryAddress ?? "Unknown delivery",
    order.packageDetails ?? "Package",
  )
  const createdAt = order.createdAt ?? new Date().toISOString()
  const status = order.status ?? "pending"

  return {
    id: order.id ?? `${ORDER_PREFIX}001`,
    type,
    pickupAddress: order.pickupAddress ?? "Unknown pickup",
    deliveryAddress: order.deliveryAddress ?? "Unknown delivery",
    packageDetails: order.packageDetails ?? "Package",
    price: order.price ?? quote.price,
    estimatedTime: order.estimatedTime ?? quote.estimatedTime,
    distanceKm: order.distanceKm ?? quote.distanceKm,
    status,
    createdAt,
    scheduledFor: order.scheduledFor,
    paymentMethod: order.paymentMethod ?? "cash",
    customerName: order.customerName ?? DEFAULT_PROFILE.name,
    customerPhone: order.customerPhone ?? DEFAULT_PROFILE.phone,
    deliveryPartner: order.deliveryPartner,
    partnerPhone: order.partnerPhone,
    partnerId: order.partnerId,
    pickupLocation: order.pickupLocation,
    deliveryLocation: order.deliveryLocation,
    statusHistory:
      order.statusHistory && order.statusHistory.length > 0
        ? order.statusHistory
        : [{ status, label: status === "pending" ? "Order placed" : "Status updated", timestamp: createdAt }],
    rating: order.rating,
    notes: order.notes,
  }
}

const generateOrderId = (existingOrders: Order[]): string => {
  const lastOrder = [...existingOrders].sort((a, b) => {
    const numA = Number.parseInt(a.id.replace(ORDER_PREFIX, ""), 10) || 0
    const numB = Number.parseInt(b.id.replace(ORDER_PREFIX, ""), 10) || 0
    return numB - numA
  })[0]

  const nextNum = lastOrder ? (Number.parseInt(lastOrder.id.replace(ORDER_PREFIX, ""), 10) || 0) + 1 : 1
  return `${ORDER_PREFIX}${String(nextNum).padStart(3, "0")}`
}

const statusLabel = (status: OrderStatus): string => {
  switch (status) {
    case "pending":
      return "Waiting for a delivery partner"
    case "in_progress":
      return "Delivery is in progress"
    case "delivered":
      return "Delivered successfully"
    case "cancelled":
      return "Order cancelled"
  }
}

export function useOrders() {
  const [orders, setOrders] = useState<Order[]>([])
  const [isLoaded, setIsLoaded] = useState(false)

  useEffect(() => {
    const savedOrders = safeParse<Order[]>(localStorage.getItem(STORAGE_KEY))
    const legacyOrders = safeParse<Partial<Order>[]>(localStorage.getItem(LEGACY_STORAGE_KEY))
    const initialOrders = savedOrders?.length ? savedOrders : legacyOrders?.length ? legacyOrders.map(normalizeOrder) : demoOrders

    setOrders(initialOrders.map(normalizeOrder))
    setIsLoaded(true)
  }, [])

  useEffect(() => {
    if (isLoaded) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(orders))
    }
  }, [orders, isLoaded])

  const createOrder = (payload: {
    type: OrderType
    pickupAddress: string
    deliveryAddress: string
    packageDetails: string
    paymentMethod?: PaymentMethod
    scheduledFor?: string
    pickupLocation?: LocationPoint
    deliveryLocation?: LocationPoint
  }): Order => {
    const profile = safeParse<UserProfile>(localStorage.getItem(PROFILE_KEY)) ?? DEFAULT_PROFILE
    const quote = estimateDeliveryQuote(payload.type, payload.pickupAddress, payload.deliveryAddress, payload.packageDetails)
    const createdAt = new Date().toISOString()
    const newOrder: Order = {
      id: generateOrderId(orders),
      type: payload.type,
      pickupAddress: payload.pickupAddress,
      deliveryAddress: payload.deliveryAddress,
      packageDetails: payload.packageDetails,
      price: quote.price,
      estimatedTime: quote.estimatedTime,
      distanceKm: quote.distanceKm,
      status: "pending",
      createdAt,
      scheduledFor: payload.scheduledFor,
      paymentMethod: payload.paymentMethod ?? profile.preferredPayment,
      customerName: profile.name,
      customerPhone: profile.phone,
      pickupLocation: payload.pickupLocation,
      deliveryLocation: payload.deliveryLocation,
      statusHistory: [{ status: "pending", label: "Order placed", timestamp: createdAt }],
    }

    setOrders((current) => [...current, newOrder])
    return newOrder
  }

  const updateOrderStatus = (orderId: string, newStatus: OrderStatus, label?: string) => {
    setOrders((current) =>
      current.map((order) =>
        order.id === orderId
          ? {
              ...order,
              status: newStatus,
              statusHistory: [
                ...order.statusHistory,
                { status: newStatus, label: label ?? statusLabel(newStatus), timestamp: new Date().toISOString() },
              ],
            }
          : order,
      ),
    )
  }

  const assignOrderToPartner = (orderId: string, partnerName = "Youssef Benali") => {
    setOrders((current) =>
      current.map((order) =>
        order.id === orderId
          ? {
              ...order,
              status: "in_progress",
              deliveryPartner: partnerName,
              partnerPhone: DEFAULT_PROFILE.phone,
              partnerId: "current-partner",
              statusHistory: [
                ...order.statusHistory,
                { status: "in_progress", label: `${partnerName} accepted the delivery`, timestamp: new Date().toISOString() },
              ],
            }
          : order,
      ),
    )
  }

  const cancelOrder = (orderId: string) => {
    updateOrderStatus(orderId, "cancelled", "Cancelled by customer")
  }

  const rateOrder = (orderId: string, rating: number) => {
    setOrders((current) => current.map((order) => (order.id === orderId ? { ...order, rating } : order)))
  }

  const resetDemoData = () => {
    setOrders(demoOrders.map(normalizeOrder))
  }

  const clearOrders = () => {
    setOrders([])
  }

  return {
    orders,
    isLoaded,
    createOrder,
    updateOrderStatus,
    assignOrderToPartner,
    cancelOrder,
    rateOrder,
    resetDemoData,
    clearOrders,
    pendingOrders: orders.filter((order) => order.status === "pending"),
    activeOrders: orders.filter((order) => order.status === "in_progress"),
    deliveredOrders: orders.filter((order) => order.status === "delivered"),
  }
}

export function useProfile() {
  const [profile, setProfile] = useState<UserProfile>(DEFAULT_PROFILE)
  const [isProfileLoaded, setIsProfileLoaded] = useState(false)

  useEffect(() => {
    setProfile(safeParse<UserProfile>(localStorage.getItem(PROFILE_KEY)) ?? DEFAULT_PROFILE)
    setIsProfileLoaded(true)
  }, [])

  useEffect(() => {
    if (isProfileLoaded) {
      localStorage.setItem(PROFILE_KEY, JSON.stringify(profile))
    }
  }, [profile, isProfileLoaded])

  return {
    profile,
    isProfileLoaded,
    updateProfile: (updates: Partial<UserProfile>) => setProfile((current) => ({ ...current, ...updates })),
    resetProfile: () => setProfile(DEFAULT_PROFILE),
  }
}

export function usePartnerState() {
  const [isOnline, setIsOnlineState] = useState(false)
  const [isPartnerLoaded, setIsPartnerLoaded] = useState(false)

  useEffect(() => {
    const saved = safeParse<{ isOnline: boolean }>(localStorage.getItem(PARTNER_STATE_KEY))
    setIsOnlineState(saved?.isOnline ?? false)
    setIsPartnerLoaded(true)
  }, [])

  const setIsOnline = (value: boolean) => {
    setIsOnlineState(value)
    localStorage.setItem(PARTNER_STATE_KEY, JSON.stringify({ isOnline: value }))
  }

  return { isOnline, setIsOnline, isPartnerLoaded }
}

export function useOrderStats(orders: Order[]) {
  return useMemo(() => {
    const totalOrders = orders.length
    const delivered = orders.filter((order) => order.status === "delivered")
    const active = orders.filter((order) => order.status === "in_progress")
    const pending = orders.filter((order) => order.status === "pending")
    const cancelled = orders.filter((order) => order.status === "cancelled")
    const totalSpent = orders
      .filter((order) => order.status !== "cancelled")
      .reduce((sum, order) => sum + order.price, 0)
    const totalEarnings = delivered.reduce((sum, order) => sum + order.price, 0)

    return {
      totalOrders,
      deliveredCount: delivered.length,
      activeCount: active.length,
      pendingCount: pending.length,
      cancelledCount: cancelled.length,
      totalSpent,
      totalEarnings,
      averageOrderValue: totalOrders > 0 ? Math.round(totalSpent / totalOrders) : 0,
    }
  }, [orders])
}
