"use client"

import { useEffect, useMemo, useState } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import {
  AlertCircle,
  Banknote,
  CheckCircle,
  Clock,
  CreditCard,
  MapPin,
  Menu,
  Navigation,
  Package,
  ShieldCheck,
  Sparkles,
  Star,
  Truck,
  User,
  Wallet,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import {
  estimateDeliveryQuote,
  ORDER_TYPE_INFO,
  useOrders,
  useProfile,
  type DeliveryQuote,
  type LocationPoint,
  type Order,
  type OrderType,
  type PaymentMethod,
} from "@/hooks/useOrders"

const PICKUP_LOCATION_KEY = "deliveryfast_selected_pickup"
const DELIVERY_LOCATION_KEY = "deliveryfast_selected_delivery"
const REORDER_DRAFT_KEY = "deliveryfast_reorder_draft"

const paymentOptions: Array<{ value: PaymentMethod; label: string; icon: typeof Banknote }> = [
  { value: "cash", label: "Cash", icon: Banknote },
  { value: "card", label: "Card", icon: CreditCard },
  { value: "wallet", label: "Wallet", icon: Wallet },
]

const readLocation = (key: string): LocationPoint | null => {
  try {
    const saved = localStorage.getItem(key)
    return saved ? (JSON.parse(saved) as LocationPoint) : null
  } catch {
    return null
  }
}

export default function HomePage() {
  const router = useRouter()
  const { createOrder, orders, isLoaded } = useOrders()
  const { profile } = useProfile()
  const [pickupLocation, setPickupLocation] = useState<LocationPoint | null>(null)
  const [deliveryLocation, setDeliveryLocation] = useState<LocationPoint | null>(null)
  const [pickupAddress, setPickupAddress] = useState("")
  const [deliveryAddress, setDeliveryAddress] = useState("")
  const [packageDetails, setPackageDetails] = useState("")
  const [orderType, setOrderType] = useState<OrderType>("food")
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>("cash")
  const [scheduledFor, setScheduledFor] = useState("")
  const [quote, setQuote] = useState<DeliveryQuote | null>(null)
  const [createdOrder, setCreatedOrder] = useState<Order | null>(null)
  const [errorMessage, setErrorMessage] = useState("")

  useEffect(() => {
    const pickup = readLocation(PICKUP_LOCATION_KEY)
    const delivery = readLocation(DELIVERY_LOCATION_KEY)
    const draft = localStorage.getItem(REORDER_DRAFT_KEY)

    if (pickup) {
      setPickupLocation(pickup)
      setPickupAddress(pickup.address)
    }
    if (delivery) {
      setDeliveryLocation(delivery)
      setDeliveryAddress(delivery.address)
    }
    if (draft) {
      try {
        const parsed = JSON.parse(draft) as {
          type: OrderType
          pickupAddress: string
          deliveryAddress: string
          packageDetails: string
        }
        setOrderType(parsed.type)
        setPickupAddress(parsed.pickupAddress)
        setDeliveryAddress(parsed.deliveryAddress)
        setPackageDetails(parsed.packageDetails)
        localStorage.removeItem(REORDER_DRAFT_KEY)
      } catch {
        localStorage.removeItem(REORDER_DRAFT_KEY)
      }
    }
  }, [])

  useEffect(() => {
    if (profile.preferredPayment) setPaymentMethod(profile.preferredPayment)
  }, [profile.preferredPayment])

  const activeOrder = useMemo(() => orders.find((order) => order.status === "in_progress"), [orders])
  const pendingCount = useMemo(() => orders.filter((order) => order.status === "pending").length, [orders])

  const validateForm = () => {
    if (!pickupAddress.trim()) return "Please add a pickup address."
    if (!deliveryAddress.trim()) return "Please add a delivery address."
    if (!packageDetails.trim()) return "Please describe the package."
    if (pickupAddress.trim().toLowerCase() === deliveryAddress.trim().toLowerCase()) {
      return "Pickup and delivery addresses should be different."
    }
    return ""
  }

  const handleGetQuote = () => {
    const message = validateForm()
    if (message) {
      setErrorMessage(message)
      setQuote(null)
      return
    }

    setErrorMessage("")
    setCreatedOrder(null)
    setQuote(estimateDeliveryQuote(orderType, pickupAddress, deliveryAddress, packageDetails))
  }

  const handleConfirmOrder = () => {
    if (!quote) return

    const order = createOrder({
      type: orderType,
      pickupAddress,
      deliveryAddress,
      packageDetails,
      paymentMethod,
      scheduledFor: scheduledFor || undefined,
      pickupLocation: pickupLocation ?? { address: pickupAddress },
      deliveryLocation: deliveryLocation ?? { address: deliveryAddress },
    })

    setCreatedOrder(order)
    setQuote(null)
    setPickupAddress("")
    setDeliveryAddress("")
    setPackageDetails("")
    setScheduledFor("")
    localStorage.removeItem(PICKUP_LOCATION_KEY)
    localStorage.removeItem(DELIVERY_LOCATION_KEY)
    setPickupLocation(null)
    setDeliveryLocation(null)
  }

  const selectCategory = (type: OrderType) => {
    setOrderType(type)
    setQuote(null)
    setCreatedOrder(null)
    document.getElementById("order-card")?.scrollIntoView({ behavior: "smooth", block: "start" })
  }

  return (
    <div className="min-h-screen bg-slate-50 pb-24">
      <header className="sticky top-0 z-50 border-b bg-white/95 backdrop-blur">
        <div className="flex items-center justify-between p-4">
          <Link href="/" className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-blue-600 shadow-sm">
              <Truck className="h-6 w-6 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-extrabold tracking-tight text-blue-600">Deliveryfast</h1>
              <p className="text-xs text-slate-500">Local delivery in Morocco</p>
            </div>
          </Link>

          <Sheet>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" aria-label="Open navigation menu">
                <Menu className="h-6 w-6" />
              </Button>
            </SheetTrigger>
            <SheetContent>
              <div className="mt-8 space-y-2">
                <Link href="/" className="flex items-center gap-3 rounded-lg p-3 hover:bg-slate-100">
                  <Package className="h-5 w-5" />
                  <span>Place Order</span>
                </Link>
                <Link href="/orders" className="flex items-center gap-3 rounded-lg p-3 hover:bg-slate-100">
                  <Clock className="h-5 w-5" />
                  <span>My Orders</span>
                </Link>
                <Link href="/delivery" className="flex items-center gap-3 rounded-lg p-3 hover:bg-slate-100">
                  <Truck className="h-5 w-5" />
                  <span>Delivery Partner</span>
                </Link>
                <Link href="/profile" className="flex items-center gap-3 rounded-lg p-3 hover:bg-slate-100">
                  <User className="h-5 w-5" />
                  <span>Profile</span>
                </Link>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </header>

      <section className="bg-gradient-to-b from-blue-50 via-white to-slate-50 px-4 py-8 text-center">
        <Badge variant="secondary" className="mb-4 gap-1 rounded-full px-3 py-1">
          <Sparkles className="h-3.5 w-3.5" />
          Live demo with saved orders
        </Badge>
        <h2 className="mx-auto max-w-xs text-4xl font-black leading-tight text-slate-950">Fast Local Delivery</h2>
        <p className="mx-auto mt-3 max-w-sm text-slate-600">Book, track, accept, complete, and manage deliveries from one mobile-friendly app.</p>
        <div className="mt-6 flex justify-center gap-3">
          <Badge variant="outline" className="gap-1 rounded-full bg-white px-3 py-2">
            <Clock className="h-4 w-4" />
            20-60 min
          </Badge>
          <Badge variant="outline" className="gap-1 rounded-full bg-white px-3 py-2">
            <ShieldCheck className="h-4 w-4" />
            Verified partners
          </Badge>
        </div>
      </section>

      {activeOrder && (
        <div className="px-4 pb-4">
          <Card className="border-blue-200 bg-blue-50">
            <CardContent className="flex items-center justify-between gap-3 p-4">
              <div>
                <p className="text-sm font-semibold text-blue-900">Active delivery #{activeOrder.id}</p>
                <p className="line-clamp-1 text-xs text-blue-700">{activeOrder.deliveryPartner ?? "Partner"} is delivering to {activeOrder.deliveryAddress}</p>
              </div>
              <Button size="sm" onClick={() => router.push(`/map?track=${activeOrder.id}`)}>
                Track
              </Button>
            </CardContent>
          </Card>
        </div>
      )}

      {createdOrder && (
        <div className="px-4 pb-4">
          <Card className="border-green-200 bg-green-50">
            <CardContent className="space-y-3 p-4">
              <div className="flex gap-3">
                <CheckCircle className="mt-0.5 h-5 w-5 flex-none text-green-600" />
                <div>
                  <p className="font-semibold text-green-900">Order #{createdOrder.id} created successfully.</p>
                  <p className="text-sm text-green-700">A delivery partner can now accept it from the partner dashboard.</p>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <Button variant="outline" className="bg-white" onClick={() => router.push("/orders")}>
                  View order
                </Button>
                <Button onClick={() => router.push("/delivery")}>Partner dashboard</Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      <div className="px-4">
        <Card id="order-card" className="shadow-sm">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-2xl">
              <Package className="h-6 w-6" />
              Place New Order
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-5">
            {errorMessage && (
              <div className="flex gap-2 rounded-lg border border-red-200 bg-red-50 p-3 text-sm text-red-700">
                <AlertCircle className="mt-0.5 h-4 w-4 flex-none" />
                {errorMessage}
              </div>
            )}

            <div className="space-y-2">
              <Label htmlFor="from">Pickup Location *</Label>
              <div className="relative">
                <MapPin className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
                <Input
                  id="from"
                  placeholder="Enter pickup address"
                  value={pickupAddress}
                  onChange={(event) => {
                    setPickupAddress(event.target.value)
                    setPickupLocation({ address: event.target.value })
                    setQuote(null)
                  }}
                  className="pl-10"
                />
              </div>
              <Link href="/map?type=pickup" className="inline-flex items-center gap-1 text-sm font-medium text-blue-600">
                <Navigation className="h-4 w-4" />
                Choose on map
              </Link>
            </div>

            <div className="space-y-2">
              <Label htmlFor="to">Delivery Location *</Label>
              <div className="relative">
                <MapPin className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
                <Input
                  id="to"
                  placeholder="Enter delivery address"
                  value={deliveryAddress}
                  onChange={(event) => {
                    setDeliveryAddress(event.target.value)
                    setDeliveryLocation({ address: event.target.value })
                    setQuote(null)
                  }}
                  className="pl-10"
                />
              </div>
              <Link href="/map?type=delivery" className="inline-flex items-center gap-1 text-sm font-medium text-blue-600">
                <Navigation className="h-4 w-4" />
                Choose on map
              </Link>
            </div>

            <div className="space-y-2">
              <Label htmlFor="package">Package Details *</Label>
              <Textarea
                id="package"
                placeholder="Describe size, weight, value, and special instructions"
                value={packageDetails}
                onChange={(event) => {
                  setPackageDetails(event.target.value)
                  setQuote(null)
                }}
                rows={4}
              />
            </div>

            <div className="space-y-3">
              <Label>Delivery Type *</Label>
              <div className="grid grid-cols-2 gap-3">
                {(Object.entries(ORDER_TYPE_INFO) as Array<[OrderType, (typeof ORDER_TYPE_INFO)[OrderType]]>).map(([type, info]) => (
                  <button
                    key={type}
                    type="button"
                    onClick={() => selectCategory(type)}
                    className={`rounded-2xl border p-3 text-left transition ${
                      orderType === type ? "border-blue-600 bg-blue-50 shadow-sm" : "border-slate-200 bg-white hover:border-blue-200"
                    }`}
                  >
                    <div className="text-2xl">{info.icon}</div>
                    <div className="mt-1 text-sm font-semibold">{info.name}</div>
                    <div className="mt-1 flex items-center gap-1 text-xs text-slate-500">
                      <Clock className="h-3 w-3" />
                      from {info.baseTime} min
                    </div>
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-3">
              <Label>Payment Method</Label>
              <div className="grid grid-cols-3 gap-2">
                {paymentOptions.map((payment) => {
                  const Icon = payment.icon
                  return (
                    <button
                      type="button"
                      key={payment.value}
                      onClick={() => setPaymentMethod(payment.value)}
                      className={`rounded-xl border p-3 text-center text-sm transition ${
                        paymentMethod === payment.value ? "border-blue-600 bg-blue-50 font-semibold text-blue-700" : "border-slate-200"
                      }`}
                    >
                      <Icon className="mx-auto mb-1 h-4 w-4" />
                      {payment.label}
                    </button>
                  )
                })}
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="schedule">Schedule time (optional)</Label>
              <Input id="schedule" type="datetime-local" value={scheduledFor} onChange={(event) => setScheduledFor(event.target.value)} />
            </div>

            <Button onClick={handleGetQuote} className="w-full" size="lg" disabled={!isLoaded}>
              Get Delivery Quote
            </Button>
          </CardContent>
        </Card>
      </div>

      {quote && (
        <div className="p-4">
          <Card className="border-green-200 bg-green-50 shadow-sm">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-green-800">
                <CheckCircle className="h-5 w-5" />
                Delivery Quote
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="rounded-2xl bg-white p-4 text-sm shadow-sm">
                <div className="flex justify-between py-2">
                  <span className="text-slate-500">Service</span>
                  <span className="font-semibold">{ORDER_TYPE_INFO[quote.type].name}</span>
                </div>
                <div className="flex justify-between py-2">
                  <span className="text-slate-500">Distance</span>
                  <span className="font-semibold">{quote.distanceKm} km</span>
                </div>
                <div className="flex justify-between py-2">
                  <span className="text-slate-500">Estimated time</span>
                  <span className="font-semibold text-blue-600">{quote.estimatedTime} min</span>
                </div>
                <div className="flex justify-between py-2">
                  <span className="text-slate-500">Base + service fee</span>
                  <span>{quote.basePrice} + {quote.serviceFee} MAD</span>
                </div>
                <div className="mt-2 flex justify-between border-t pt-3 text-base">
                  <span className="font-semibold">Total</span>
                  <span className="text-xl font-black text-green-600">{quote.price} MAD</span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <Button variant="outline" className="bg-white" onClick={() => setQuote(null)}>
                  Edit
                </Button>
                <Button onClick={handleConfirmOrder} className="bg-green-600 hover:bg-green-700">
                  Confirm Order
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      <section className="p-4">
        <div className="mb-4 flex items-center justify-between">
          <h3 className="text-2xl font-bold">What can we deliver?</h3>
          {pendingCount > 0 && <Badge variant="secondary">{pendingCount} waiting</Badge>}
        </div>
        <div className="grid grid-cols-2 gap-3">
          {(Object.entries(ORDER_TYPE_INFO) as Array<[OrderType, (typeof ORDER_TYPE_INFO)[OrderType]]>).slice(0, 4).map(([type, info]) => (
            <button key={type} onClick={() => selectCategory(type)} className="rounded-2xl border bg-white p-4 text-center shadow-sm transition hover:-translate-y-0.5 hover:shadow-md">
              <div className="text-4xl">{info.icon}</div>
              <div className="mt-3 font-bold">{info.name}</div>
              <div className="mt-1 flex items-center justify-center gap-1 text-sm text-slate-500">
                <Clock className="h-4 w-4" />
                {info.baseTime}-{info.baseTime + 20} min
              </div>
            </button>
          ))}
        </div>
      </section>

      <div className="fixed bottom-0 left-0 right-0 mx-auto max-w-md border-t bg-white/95 backdrop-blur">
        <div className="grid grid-cols-4 py-2 text-xs">
          <Link href="/" className="flex flex-col items-center gap-1 p-2 font-medium text-blue-600">
            <Package className="h-5 w-5" />
            Order
          </Link>
          <Link href="/orders" className="flex flex-col items-center gap-1 p-2 text-slate-500">
            <Clock className="h-5 w-5" />
            Orders
          </Link>
          <Link href="/delivery" className="flex flex-col items-center gap-1 p-2 text-slate-500">
            <Truck className="h-5 w-5" />
            Deliver
          </Link>
          <Link href="/profile" className="flex flex-col items-center gap-1 p-2 text-slate-500">
            <User className="h-5 w-5" />
            Profile
          </Link>
        </div>
      </div>
    </div>
  )
}
