"use client"

import { useMemo, useState } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { ArrowLeft, Clock, MapPin, MessageCircle, Package, Phone, RotateCcw, Star, Trash2, Truck, User } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import { ORDER_TYPE_INFO, useOrders, type Order, type OrderStatus } from "@/hooks/useOrders"

const REORDER_DRAFT_KEY = "deliveryfast_reorder_draft"

const filterOptions: Array<{ value: OrderStatus | "all"; label: string }> = [
  { value: "all", label: "All" },
  { value: "pending", label: "Pending" },
  { value: "in_progress", label: "Active" },
  { value: "delivered", label: "Delivered" },
  { value: "cancelled", label: "Cancelled" },
]

const statusText: Record<OrderStatus, string> = {
  pending: "Pending",
  in_progress: "In transit",
  delivered: "Delivered",
  cancelled: "Cancelled",
}

const statusClass: Record<OrderStatus, string> = {
  pending: "bg-yellow-100 text-yellow-800 hover:bg-yellow-100",
  in_progress: "bg-blue-100 text-blue-800 hover:bg-blue-100",
  delivered: "bg-green-100 text-green-800 hover:bg-green-100",
  cancelled: "bg-red-100 text-red-800 hover:bg-red-100",
}

function OrderTimeline({ order }: { order: Order }) {
  return (
    <div className="space-y-2 rounded-2xl bg-slate-50 p-3">
      {order.statusHistory.slice(-3).map((event, index) => (
        <div key={`${event.timestamp}-${index}`} className="flex gap-3 text-sm">
          <div className={`mt-1.5 h-2.5 w-2.5 rounded-full ${event.status === "delivered" ? "bg-green-500" : event.status === "cancelled" ? "bg-red-500" : "bg-blue-500"}`}></div>
          <div>
            <p className="font-medium">{event.label}</p>
            <p className="text-xs text-slate-500">{new Date(event.timestamp).toLocaleString()}</p>
          </div>
        </div>
      ))}
    </div>
  )
}

export default function OrdersPage() {
  const router = useRouter()
  const { orders, isLoaded, cancelOrder, rateOrder } = useOrders()
  const [activeTab, setActiveTab] = useState<OrderStatus | "all">("all")

  const filteredOrders = useMemo(() => {
    const sorted = [...orders].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    if (activeTab === "all") return sorted
    return sorted.filter((order) => order.status === activeTab)
  }, [orders, activeTab])

  const getCount = (status: OrderStatus | "all") => (status === "all" ? orders.length : orders.filter((order) => order.status === status).length)

  const callPartner = (order: Order) => {
    window.location.href = `tel:${order.partnerPhone ?? order.customerPhone}`
  }

  const messagePartner = (order: Order) => {
    window.location.href = `sms:${order.partnerPhone ?? order.customerPhone}?body=Hi, I am checking order ${order.id}.`
  }

  const reorder = (order: Order) => {
    localStorage.setItem(
      REORDER_DRAFT_KEY,
      JSON.stringify({
        type: order.type,
        pickupAddress: order.pickupAddress,
        deliveryAddress: order.deliveryAddress,
        packageDetails: order.packageDetails,
      }),
    )
    router.push("/")
  }

  if (!isLoaded) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-slate-50">
        <div className="text-center">
          <div className="mx-auto mb-4 h-12 w-12 animate-spin rounded-full border-b-2 border-blue-600"></div>
          <p className="text-slate-600">Loading your orders...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-slate-50 pb-24">
      <header className="sticky top-0 z-50 border-b bg-white">
        <div className="flex items-center gap-4 p-4">
          <Link href="/">
            <Button variant="ghost" size="icon" aria-label="Back home">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
          <div>
            <h1 className="text-xl font-bold">My Orders</h1>
            <p className="text-xs text-slate-500">Track, cancel, rate, or reorder</p>
          </div>
          <Badge variant="secondary" className="ml-auto">{filteredOrders.length}</Badge>
        </div>
      </header>

      <div className="sticky top-[73px] z-40 border-b bg-white px-2 py-2">
        <Tabs value={activeTab} onValueChange={(value) => setActiveTab(value as OrderStatus | "all")}>
          <TabsList className="h-auto w-full justify-start overflow-x-auto rounded-none bg-transparent p-0">
            {filterOptions.map((option) => (
              <TabsTrigger key={option.value} value={option.value} className="rounded-full px-3 py-2 data-[state=active]:bg-blue-600 data-[state=active]:text-white">
                {option.label} {getCount(option.value) > 0 ? getCount(option.value) : ""}
              </TabsTrigger>
            ))}
          </TabsList>
        </Tabs>
      </div>

      {filteredOrders.length > 0 ? (
        <div className="space-y-4 p-4">
          {filteredOrders.map((order) => {
            const type = ORDER_TYPE_INFO[order.type]
            return (
              <Card key={order.id} className={`shadow-sm ${order.status === "cancelled" ? "opacity-70" : ""}`}>
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <div className="text-3xl">{type.icon}</div>
                      <div>
                        <CardTitle className="text-lg">Order #{order.id}</CardTitle>
                        <p className="text-xs text-slate-500">{new Date(order.createdAt).toLocaleString()}</p>
                      </div>
                    </div>
                    <Badge className={statusClass[order.status]}>{statusText[order.status]}</Badge>
                  </div>
                </CardHeader>

                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex items-start gap-3">
                      <div className="mt-1.5 h-3 w-3 rounded-full bg-green-500"></div>
                      <div>
                        <div className="text-sm font-semibold">From</div>
                        <div className="text-sm text-slate-600">{order.pickupAddress}</div>
                      </div>
                    </div>
                    <div className="ml-1.5 h-5 w-0.5 bg-slate-300"></div>
                    <div className="flex items-start gap-3">
                      <div className="mt-1.5 h-3 w-3 rounded-full bg-red-500"></div>
                      <div>
                        <div className="text-sm font-semibold">To</div>
                        <div className="text-sm text-slate-600">{order.deliveryAddress}</div>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-start gap-2 rounded-2xl bg-slate-50 p-3 text-sm">
                    <Package className="mt-0.5 h-4 w-4 flex-none text-slate-400" />
                    <span>{order.packageDetails}</span>
                  </div>

                  <div className="grid grid-cols-3 gap-2 text-center text-sm">
                    <div className="rounded-xl bg-slate-50 p-3">
                      <Clock className="mx-auto mb-1 h-4 w-4 text-slate-500" />
                      <p className="font-semibold">{order.estimatedTime} min</p>
                    </div>
                    <div className="rounded-xl bg-slate-50 p-3">
                      <MapPin className="mx-auto mb-1 h-4 w-4 text-slate-500" />
                      <p className="font-semibold">{order.distanceKm} km</p>
                    </div>
                    <div className="rounded-xl bg-blue-50 p-3">
                      <p className="text-xs text-blue-700">Total</p>
                      <p className="font-black text-blue-700">{order.price} MAD</p>
                    </div>
                  </div>

                  {order.deliveryPartner && (
                    <div className="rounded-2xl border p-3">
                      <p className="text-xs text-slate-500">Delivery Partner</p>
                      <div className="flex items-center justify-between gap-2">
                        <p className="font-semibold">{order.deliveryPartner}</p>
                        <div className="flex gap-2">
                          <Button variant="outline" size="sm" onClick={() => callPartner(order)}>
                            <Phone className="h-4 w-4" />
                          </Button>
                          <Button variant="outline" size="sm" onClick={() => messagePartner(order)}>
                            <MessageCircle className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  )}

                  <OrderTimeline order={order} />

                  {order.status === "in_progress" && (
                    <Button className="w-full" onClick={() => router.push(`/map?track=${order.id}`)}>
                      <Truck className="mr-2 h-4 w-4" />
                      Track live route
                    </Button>
                  )}

                  {order.status === "pending" && (
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button className="w-full text-red-600 hover:text-red-700" size="sm" variant="outline">
                          <Trash2 className="mr-2 h-4 w-4" />
                          Cancel Order
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogTitle>Cancel order #{order.id}?</AlertDialogTitle>
                        <AlertDialogDescription>This will update the order status and remove it from the partner queue.</AlertDialogDescription>
                        <div className="flex justify-end gap-2">
                          <AlertDialogCancel>Keep Order</AlertDialogCancel>
                          <AlertDialogAction onClick={() => cancelOrder(order.id)} className="bg-red-600 hover:bg-red-700">
                            Cancel Order
                          </AlertDialogAction>
                        </div>
                      </AlertDialogContent>
                    </AlertDialog>
                  )}

                  {order.status === "delivered" && (
                    <div className="space-y-3 rounded-2xl border p-3">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-semibold">Rate delivery</span>
                        <div className="flex gap-1">
                          {[1, 2, 3, 4, 5].map((value) => (
                            <button key={value} onClick={() => rateOrder(order.id, value)} aria-label={`Rate ${value} stars`}>
                              <Star className={`h-5 w-5 ${order.rating && order.rating >= value ? "fill-yellow-400 text-yellow-400" : "text-slate-300"}`} />
                            </button>
                          ))}
                        </div>
                      </div>
                      <Button variant="outline" className="w-full" onClick={() => reorder(order)}>
                        <RotateCcw className="mr-2 h-4 w-4" />
                        Reorder same route
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>
            )
          })}
        </div>
      ) : (
        <div className="flex flex-col items-center justify-center px-4 py-20 text-center">
          <Package className="mb-4 h-16 w-16 text-slate-300" />
          <h3 className="mb-2 text-lg font-semibold">No orders here</h3>
          <p className="mb-6 text-slate-600">Create a delivery order and it will appear here immediately.</p>
          <Link href="/">
            <Button>Place Order</Button>
          </Link>
        </div>
      )}

      <div className="fixed bottom-0 left-0 right-0 mx-auto max-w-md border-t bg-white/95 backdrop-blur">
        <div className="grid grid-cols-4 py-2 text-xs">
          <Link href="/" className="flex flex-col items-center gap-1 p-2 text-slate-500">
            <Package className="h-5 w-5" />
            Order
          </Link>
          <Link href="/orders" className="flex flex-col items-center gap-1 p-2 font-medium text-blue-600">
            <Clock className="h-5 w-5" />
            Orders
          </Link>
          <Link href="/delivery" className="flex flex-col items-center gap-1 p-2 text-slate-500">
            <Truck className="h-5 w-5" />
            Deliver
          </Link>
          <Link href="/profile" className="flex flex-col items-center gap-1 p-2 text-slate-500">
            <User className="h-5 w-5" />
            Profile
          </Link>
        </div>
      </div>
    </div>
  )
}
