"use client"

import { useMemo } from "react"
import Link from "next/link"
import { ArrowLeft, CheckCircle, Clock, DollarSign, MapPin, Navigation, Package, Star, Truck, User } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"
import { Progress } from "@/components/ui/progress"
import { ORDER_TYPE_INFO, useOrders, useOrderStats, usePartnerState, useProfile, type Order } from "@/hooks/useOrders"

const statusBadgeClass = "bg-blue-100 text-blue-800 hover:bg-blue-100"

const getProgress = (order: Order) => {
  const started = [...order.statusHistory].reverse().find((event) => event.status === "in_progress")
  if (!started) return 25
  const minutes = Math.floor((Date.now() - new Date(started.timestamp).getTime()) / 60000)
  return Math.min(95, Math.max(35, 35 + minutes * 2))
}

const openRoute = (pickup: string, delivery: string) => {
  window.open(`https://www.google.com/maps/dir/?api=1&origin=${encodeURIComponent(pickup)}&destination=${encodeURIComponent(delivery)}`, "_blank")
}

export default function DeliveryPage() {
  const { orders, isLoaded, assignOrderToPartner, updateOrderStatus } = useOrders()
  const { profile } = useProfile()
  const { isOnline, setIsOnline, isPartnerLoaded } = usePartnerState()
  const stats = useOrderStats(orders)

  const availableOrders = useMemo(() => orders.filter((order) => order.status === "pending"), [orders])
  const currentDeliveries = useMemo(
    () => orders.filter((order) => order.status === "in_progress" && (order.partnerId === "current-partner" || order.partnerId === "partner-demo")),
    [orders],
  )
  const completedDeliveries = useMemo(() => orders.filter((order) => order.status === "delivered" && order.deliveryPartner), [orders])

  const handleAcceptOrder = (orderId: string) => {
    assignOrderToPartner(orderId, profile.name)
  }

  const handleCompleteDelivery = (orderId: string) => {
    updateOrderStatus(orderId, "delivered", "Completed by delivery partner")
  }

  if (!isLoaded || !isPartnerLoaded) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-slate-50">
        <div className="text-center">
          <div className="mx-auto mb-4 h-12 w-12 animate-spin rounded-full border-b-2 border-blue-600"></div>
          <p className="text-slate-600">Loading delivery dashboard...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-slate-50 pb-24">
      <header className="sticky top-0 z-50 border-b bg-white">
        <div className="flex items-center gap-4 p-4">
          <Link href="/">
            <Button variant="ghost" size="icon" aria-label="Back home">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
          <div>
            <h1 className="text-xl font-bold">Delivery Partner</h1>
            <p className="text-xs text-slate-500">Accept orders and update delivery status</p>
          </div>
        </div>
      </header>

      <div className="p-4">
        <Card className="shadow-sm">
          <CardContent className="flex items-center justify-between gap-4 p-4">
            <div className="flex items-center gap-3">
              <div className={`h-3 w-3 rounded-full ${isOnline ? "bg-green-500" : "bg-slate-400"}`}></div>
              <div>
                <div className="font-semibold">{isOnline ? "Online" : "Offline"}</div>
                <div className="text-sm text-slate-600">{isOnline ? `${availableOrders.length} orders available now` : "Turn on to accept orders"}</div>
              </div>
            </div>
            <Switch checked={isOnline} onCheckedChange={setIsOnline} />
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-3 gap-3 px-4 pb-4">
        <Card>
          <CardContent className="p-3 text-center">
            <div className="text-xl font-black text-blue-600">{stats.pendingCount}</div>
            <div className="text-xs text-slate-500">Pending</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-3 text-center">
            <div className="text-xl font-black text-green-600">{completedDeliveries.length}</div>
            <div className="text-xs text-slate-500">Completed</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-3 text-center">
            <div className="text-xl font-black text-amber-600">{stats.totalEarnings}</div>
            <div className="text-xs text-slate-500">MAD Earned</div>
          </CardContent>
        </Card>
      </div>

      {currentDeliveries.length > 0 && (
        <section className="px-4 pb-4">
          <h2 className="mb-3 text-xl font-bold">Current Delivery</h2>
          <div className="space-y-3">
            {currentDeliveries.map((delivery) => {
              const type = ORDER_TYPE_INFO[delivery.type]
              const progress = getProgress(delivery)
              return (
                <Card key={delivery.id} className="shadow-sm">
                  <CardHeader className="pb-3">
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <CardTitle className="text-lg">Order #{delivery.id}</CardTitle>
                        <Badge className={`${statusBadgeClass} mt-2`}>In Progress</Badge>
                      </div>
                      <div className="text-right">
                        <div className="text-2xl">{type.icon}</div>
                        <div className="font-black text-green-600">{delivery.price} MAD</div>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <div className="flex items-start gap-3">
                        <div className="mt-1.5 h-3 w-3 rounded-full bg-green-500"></div>
                        <div>
                          <div className="text-sm font-semibold">From</div>
                          <div className="text-sm text-slate-600">{delivery.pickupAddress}</div>
                        </div>
                      </div>
                      <div className="ml-1.5 h-5 w-0.5 bg-slate-300"></div>
                      <div className="flex items-start gap-3">
                        <div className="mt-1.5 h-3 w-3 rounded-full bg-red-500"></div>
                        <div>
                          <div className="text-sm font-semibold">To</div>
                          <div className="text-sm text-slate-600">{delivery.deliveryAddress}</div>
                        </div>
                      </div>
                    </div>

                    <div className="rounded-2xl bg-slate-50 p-3 text-sm">
                      <div className="mb-2 flex items-start gap-2">
                        <Package className="mt-0.5 h-4 w-4 text-slate-400" />
                        <span>{delivery.packageDetails}</span>
                      </div>
                      <div className="flex items-center justify-between text-xs text-slate-500">
                        <span>Customer: {delivery.customerName}</span>
                        <span>{delivery.paymentMethod.toUpperCase()}</span>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>Progress</span>
                        <span className="font-semibold">{progress}%</span>
                      </div>
                      <Progress value={progress} />
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      <Button onClick={() => openRoute(delivery.pickupAddress, delivery.deliveryAddress)}>
                        <Navigation className="mr-2 h-4 w-4" />
                        Navigate
                      </Button>
                      <Button variant="outline" onClick={() => handleCompleteDelivery(delivery.id)}>
                        <CheckCircle className="mr-2 h-4 w-4" />
                        Complete
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </section>
      )}

      {isOnline && availableOrders.length > 0 && (
        <section className="px-4 pb-4">
          <h2 className="mb-3 text-xl font-bold">Available Orders</h2>
          <div className="space-y-3">
            {availableOrders.map((order) => {
              const type = ORDER_TYPE_INFO[order.type]
              return (
                <Card key={order.id} className="shadow-sm transition hover:shadow-md">
                  <CardContent className="space-y-4 p-4">
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex items-center gap-3">
                        <div className="text-2xl">{type.icon}</div>
                        <div>
                          <div className="font-bold">Order #{order.id}</div>
                          <div className="text-xs text-slate-500">{new Date(order.createdAt).toLocaleTimeString()}</div>
                        </div>
                      </div>
                      <div className="text-right font-black text-green-600">{order.price} MAD</div>
                    </div>

                    <div className="space-y-2 text-sm">
                      <div className="flex gap-2">
                        <div className="mt-1.5 h-2.5 w-2.5 flex-none rounded-full bg-green-500"></div>
                        <span className="text-slate-600">From:</span>
                        <span className="font-medium">{order.pickupAddress}</span>
                      </div>
                      <div className="flex gap-2">
                        <div className="mt-1.5 h-2.5 w-2.5 flex-none rounded-full bg-red-500"></div>
                        <span className="text-slate-600">To:</span>
                        <span className="font-medium">{order.deliveryAddress}</span>
                      </div>
                    </div>

                    <div className="grid grid-cols-3 gap-2 text-center text-sm">
                      <div className="rounded-xl bg-slate-50 p-2">
                        <MapPin className="mx-auto h-4 w-4 text-slate-500" />
                        <p className="font-semibold">{order.distanceKm} km</p>
                      </div>
                      <div className="rounded-xl bg-slate-50 p-2">
                        <Clock className="mx-auto h-4 w-4 text-slate-500" />
                        <p className="font-semibold">{order.estimatedTime} min</p>
                      </div>
                      <div className="rounded-xl bg-green-50 p-2">
                        <DollarSign className="mx-auto h-4 w-4 text-green-600" />
                        <p className="font-semibold text-green-700">{order.paymentMethod}</p>
                      </div>
                    </div>

                    <Button onClick={() => handleAcceptOrder(order.id)} className="w-full bg-blue-600 hover:bg-blue-700">
                      Accept Order
                    </Button>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </section>
      )}

      {isOnline && availableOrders.length === 0 && currentDeliveries.length === 0 && (
        <div className="flex flex-col items-center justify-center px-4 py-16 text-center">
          <Truck className="mb-4 h-16 w-16 text-slate-300" />
          <h3 className="mb-2 text-lg font-semibold">No orders available</h3>
          <p className="text-slate-600">New customer orders will appear here in real time.</p>
        </div>
      )}

      {!isOnline && currentDeliveries.length === 0 && (
        <div className="flex flex-col items-center justify-center px-4 py-16 text-center">
          <Truck className="mb-4 h-16 w-16 text-slate-300" />
          <h3 className="mb-2 text-lg font-semibold">You&apos;re offline</h3>
          <p className="mb-6 text-slate-600">Turn on availability to start receiving delivery requests.</p>
          <Button onClick={() => setIsOnline(true)}>Go online</Button>
        </div>
      )}

      {completedDeliveries.length > 0 && (
        <section className="px-4 pb-4">
          <h2 className="mb-3 text-xl font-bold">Completed Deliveries</h2>
          <Card>
            <CardContent className="grid grid-cols-3 gap-4 p-4 text-center">
              <div>
                <div className="text-2xl font-black text-green-600">{completedDeliveries.length}</div>
                <div className="text-xs text-slate-500">Delivered</div>
              </div>
              <div>
                <div className="text-2xl font-black text-blue-600">{completedDeliveries.reduce((sum, order) => sum + order.price, 0)}</div>
                <div className="text-xs text-slate-500">MAD</div>
              </div>
              <div>
                <div className="flex items-center justify-center gap-1">
                  <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                  <span className="text-2xl font-black">{profile.rating}</span>
                </div>
                <div className="text-xs text-slate-500">Rating</div>
              </div>
            </CardContent>
          </Card>
        </section>
      )}

      <div className="fixed bottom-0 left-0 right-0 mx-auto max-w-md border-t bg-white/95 backdrop-blur">
        <div className="grid grid-cols-4 py-2 text-xs">
          <Link href="/" className="flex flex-col items-center gap-1 p-2 text-slate-500">
            <Package className="h-5 w-5" />
            Order
          </Link>
          <Link href="/orders" className="flex flex-col items-center gap-1 p-2 text-slate-500">
            <Clock className="h-5 w-5" />
            Orders
          </Link>
          <Link href="/delivery" className="flex flex-col items-center gap-1 p-2 font-medium text-blue-600">
            <Truck className="h-5 w-5" />
            Deliver
          </Link>
          <Link href="/profile" className="flex flex-col items-center gap-1 p-2 text-slate-500">
            <User className="h-5 w-5" />
            Profile
          </Link>
        </div>
      </div>
    </div>
  )
}
