"use client"

import { Suspense, useMemo, useState } from "react"
import Link from "next/link"
import { useRouter, useSearchParams } from "next/navigation"
import { ArrowLeft, Clock, LocateFixed, MapPin, Navigation, Package, Route, Search, Truck } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { useOrders, type LocationPoint } from "@/hooks/useOrders"

const PICKUP_LOCATION_KEY = "deliveryfast_selected_pickup"
const DELIVERY_LOCATION_KEY = "deliveryfast_selected_delivery"

const locations: LocationPoint[] = [
  { address: "Maarif, Casablanca", lat: 33.5868, lng: -7.6327 },
  { address: "Ain Diab, Casablanca", lat: 33.5963, lng: -7.6812 },
  { address: "CIL, Casablanca", lat: 33.5587, lng: -7.6578 },
  { address: "Bourgogne, Casablanca", lat: 33.6032, lng: -7.6414 },
  { address: "Twin Center, Casablanca", lat: 33.5866, lng: -7.6328 },
  { address: "Centre Ville, Casablanca", lat: 33.5951, lng: -7.6188 },
  { address: "Agdal, Rabat", lat: 34.0019, lng: -6.8498 },
  { address: "Hassan, Rabat", lat: 34.0209, lng: -6.8335 },
  { address: "Souissi, Rabat", lat: 33.9917, lng: -6.8136 },
  { address: "Gueliz, Marrakech", lat: 31.6351, lng: -8.0088 },
  { address: "Medina, Marrakech", lat: 31.6295, lng: -7.9811 },
  { address: "Hivernage, Marrakech", lat: 31.6218, lng: -8.0147 },
]

function MapPageContent() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const type = searchParams.get("type") === "delivery" ? "delivery" : "pickup"
  const trackingId = searchParams.get("track")
  const { orders } = useOrders()
  const trackingOrder = orders.find((order) => order.id === trackingId)
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedLocation, setSelectedLocation] = useState<LocationPoint | null>(null)

  const filteredLocations = useMemo(() => {
    return locations.filter((location) => location.address.toLowerCase().includes(searchQuery.toLowerCase()))
  }, [searchQuery])

  const confirmLocation = () => {
    if (!selectedLocation) return
    localStorage.setItem(type === "pickup" ? PICKUP_LOCATION_KEY : DELIVERY_LOCATION_KEY, JSON.stringify(selectedLocation))
    router.push("/")
  }

  const openRoute = (from?: string, to?: string) => {
    const origin = encodeURIComponent(from ?? "Current Location")
    const destination = encodeURIComponent(to ?? selectedLocation?.address ?? "Casablanca")
    window.open(`https://www.google.com/maps/dir/?api=1&origin=${origin}&destination=${destination}`, "_blank")
  }

  if (trackingOrder) {
    return (
      <div className="min-h-screen bg-slate-50 pb-6">
        <header className="sticky top-0 z-50 border-b bg-white">
          <div className="flex items-center gap-4 p-4">
            <Link href="/orders">
              <Button variant="ghost" size="icon" aria-label="Back to orders">
                <ArrowLeft className="h-5 w-5" />
              </Button>
            </Link>
            <div>
              <h1 className="text-lg font-semibold">Track Order #{trackingOrder.id}</h1>
              <p className="text-xs text-slate-500">Live route preview</p>
            </div>
          </div>
        </header>

        <div className="p-4">
          <Card className="overflow-hidden">
            <CardContent className="p-0">
              <div className="relative h-80 bg-gradient-to-br from-blue-100 via-green-100 to-amber-100">
                <div className="absolute inset-6 rounded-[2rem] border-4 border-dashed border-white/80"></div>
                <div className="absolute left-10 top-12 rounded-full bg-white p-3 shadow">
                  <MapPin className="h-6 w-6 text-green-600" />
                </div>
                <div className="absolute right-10 bottom-14 rounded-full bg-white p-3 shadow">
                  <MapPin className="h-6 w-6 text-red-500" />
                </div>
                <div className="absolute left-[45%] top-[45%] rounded-full bg-blue-600 p-3 shadow-lg">
                  <Truck className="h-7 w-7 text-white" />
                </div>
                <svg viewBox="0 0 320 260" className="absolute inset-0 h-full w-full">
                  <path d="M66 70 C110 115 150 112 165 145 S225 205 265 210" fill="none" stroke="white" strokeWidth="10" strokeLinecap="round" />
                  <path d="M66 70 C110 115 150 112 165 145 S225 205 265 210" fill="none" stroke="#2563eb" strokeWidth="5" strokeLinecap="round" strokeDasharray="12 10" />
                </svg>
              </div>
            </CardContent>
          </Card>

          <Card className="mt-4">
            <CardContent className="space-y-4 p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-500">Status</p>
                  <p className="font-bold capitalize">{trackingOrder.status.replace("_", " ")}</p>
                </div>
                <Badge className={trackingOrder.status === "in_progress" ? "bg-blue-100 text-blue-700" : "bg-slate-100 text-slate-700"}>
                  {trackingOrder.estimatedTime} min
                </Badge>
              </div>
              <div className="space-y-3">
                <div className="flex gap-3">
                  <div className="mt-1 h-3 w-3 rounded-full bg-green-500"></div>
                  <div>
                    <p className="text-sm font-semibold">Pickup</p>
                    <p className="text-sm text-slate-600">{trackingOrder.pickupAddress}</p>
                  </div>
                </div>
                <div className="ml-1.5 h-6 w-0.5 bg-slate-300"></div>
                <div className="flex gap-3">
                  <div className="mt-1 h-3 w-3 rounded-full bg-red-500"></div>
                  <div>
                    <p className="text-sm font-semibold">Delivery</p>
                    <p className="text-sm text-slate-600">{trackingOrder.deliveryAddress}</p>
                  </div>
                </div>
              </div>
              <Button className="w-full" onClick={() => openRoute(trackingOrder.pickupAddress, trackingOrder.deliveryAddress)}>
                <Navigation className="mr-2 h-4 w-4" />
                Open route in Maps
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-slate-50 pb-28">
      <header className="sticky top-0 z-50 border-b bg-white">
        <div className="flex items-center gap-4 p-4">
          <Link href="/">
            <Button variant="ghost" size="icon" aria-label="Back home">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
          <div>
            <h1 className="text-lg font-semibold">Choose {type === "pickup" ? "Pickup" : "Delivery"} Location</h1>
            <p className="text-xs text-slate-500">Tap an area or use current location</p>
          </div>
        </div>
      </header>

      <div className="p-4">
        <div className="relative">
          <Search className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
          <Input placeholder="Search Casablanca, Rabat, Marrakech..." value={searchQuery} onChange={(event) => setSearchQuery(event.target.value)} className="pl-10" />
        </div>
      </div>

      <div className="mx-4 mb-4">
        <Card>
          <CardContent className="p-0">
            <div className="relative h-72 overflow-hidden rounded-lg bg-gradient-to-br from-green-100 via-blue-100 to-slate-100">
              <div className="absolute inset-0 opacity-30">
                <svg viewBox="0 0 400 300" className="h-full w-full text-green-700">
                  <path d="M50 155 Q105 88 160 118 Q210 105 260 132 Q315 150 355 172 Q320 218 282 232 Q205 252 150 236 Q96 224 50 202 Z" fill="currentColor" />
                  <path d="M115 185 Q175 145 235 180" fill="none" stroke="white" strokeWidth="10" strokeLinecap="round" />
                  <path d="M130 130 Q180 165 230 130" fill="none" stroke="white" strokeWidth="8" strokeLinecap="round" />
                </svg>
              </div>
              {filteredLocations.slice(0, 10).map((location, index) => (
                <button
                  key={location.address}
                  type="button"
                  aria-label={location.address}
                  onClick={() => setSelectedLocation(location)}
                  className={`absolute rounded-full border-2 border-white shadow transition ${selectedLocation?.address === location.address ? "h-5 w-5 bg-blue-600" : "h-4 w-4 bg-red-500 hover:scale-125"}`}
                  style={{ left: `${18 + (index % 4) * 21}%`, top: `${28 + Math.floor(index / 4) * 22}%` }}
                />
              ))}
              <div className="absolute bottom-4 left-4 right-4 rounded-2xl bg-white/90 p-3 shadow-sm backdrop-blur">
                <div className="flex items-center gap-2 text-sm font-semibold">
                  <Route className="h-4 w-4 text-blue-600" />
                  Simulated city map
                </div>
                <p className="mt-1 text-xs text-slate-500">Selections are saved back to the order form.</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="px-4">
        <h3 className="mb-3 text-lg font-semibold">Nearby areas</h3>
        <div className="space-y-2">
          {filteredLocations.map((location) => (
            <button
              key={location.address}
              type="button"
              onClick={() => setSelectedLocation(location)}
              className={`flex w-full items-center gap-3 rounded-xl border bg-white p-4 text-left transition ${selectedLocation?.address === location.address ? "border-blue-500 bg-blue-50" : "hover:bg-slate-50"}`}
            >
              <MapPin className="h-5 w-5 text-slate-400" />
              <div className="flex-1">
                <div className="font-medium">{location.address}</div>
                <div className="text-sm text-slate-500">
                  {location.lat?.toFixed(4)}, {location.lng?.toFixed(4)}
                </div>
              </div>
              {selectedLocation?.address === location.address && <Badge>Selected</Badge>}
            </button>
          ))}
        </div>
      </div>

      <div className="p-4">
        <Button
          variant="outline"
          className="w-full bg-white"
          onClick={() =>
            setSelectedLocation({
              address: "Current Location, Casablanca",
              lat: 33.5731,
              lng: -7.5898,
            })
          }
        >
          <LocateFixed className="mr-2 h-4 w-4" />
          Use Current Location
        </Button>
      </div>

      {selectedLocation && (
        <div className="fixed bottom-0 left-0 right-0 mx-auto max-w-md border-t bg-white p-4 shadow-lg">
          <div className="mb-3 flex items-start gap-3">
            <MapPin className="mt-0.5 h-5 w-5 text-blue-600" />
            <div>
              <div className="font-semibold">Selected Location</div>
              <div className="text-sm text-slate-600">{selectedLocation.address}</div>
            </div>
          </div>
          <Button className="w-full" onClick={confirmLocation}>
            Confirm {type === "pickup" ? "Pickup" : "Delivery"} Location
          </Button>
        </div>
      )}
    </div>
  )
}

export default function MapPage() {
  return (
    <Suspense
      fallback={
        <div className="flex min-h-screen items-center justify-center bg-slate-50">
          <div className="text-center">
            <Package className="mx-auto mb-3 h-10 w-10 animate-pulse text-blue-600" />
            <p className="text-slate-600">Loading map...</p>
          </div>
        </div>
      }
    >
      <MapPageContent />
    </Suspense>
  )
}
