"use client"

import Link from "next/link"
import { ArrowLeft, Bell, Clock, CreditCard, Mail, MapPin, Package, Phone, Save, Truck, User } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { useProfile, type PaymentMethod } from "@/hooks/useOrders"

export default function SettingsPage() {
  const { profile, updateProfile, resetProfile } = useProfile()

  return (
    <div className="min-h-screen bg-slate-50 pb-24">
      <header className="sticky top-0 z-50 border-b bg-white">
        <div className="flex items-center gap-4 p-4">
          <Link href="/profile">
            <Button variant="ghost" size="icon" aria-label="Back to profile">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
          <div>
            <h1 className="text-xl font-bold">Settings</h1>
            <p className="text-xs text-slate-500">Saved locally for this demo app</p>
          </div>
        </div>
      </header>

      <div className="space-y-4 p-4">
        <Card className="shadow-sm">
          <CardHeader>
            <CardTitle className="text-base">Personal details</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="name">Full name</Label>
              <div className="relative">
                <User className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
                <Input id="name" value={profile.name} onChange={(event) => updateProfile({ name: event.target.value })} className="pl-10" />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="phone">Phone</Label>
              <div className="relative">
                <Phone className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
                <Input id="phone" value={profile.phone} onChange={(event) => updateProfile({ phone: event.target.value })} className="pl-10" />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <div className="relative">
                <Mail className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
                <Input id="email" type="email" value={profile.email} onChange={(event) => updateProfile({ email: event.target.value })} className="pl-10" />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="city">City</Label>
              <div className="relative">
                <MapPin className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
                <Input id="city" value={profile.city} onChange={(event) => updateProfile({ city: event.target.value })} className="pl-10" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="shadow-sm">
          <CardHeader>
            <CardTitle className="text-base">Delivery preferences</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="payment">Default payment</Label>
              <div className="relative">
                <CreditCard className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
                <select
                  id="payment"
                  value={profile.preferredPayment}
                  onChange={(event) => updateProfile({ preferredPayment: event.target.value as PaymentMethod })}
                  className="flex h-10 w-full rounded-md border border-input bg-background px-10 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
                >
                  <option value="cash">Cash on delivery</option>
                  <option value="card">Card</option>
                  <option value="wallet">Wallet</option>
                </select>
              </div>
            </div>
            <div className="flex items-center justify-between rounded-2xl border p-4">
              <div className="flex items-center gap-3">
                <Bell className="h-5 w-5 text-slate-400" />
                <div>
                  <div className="font-medium">Push notifications</div>
                  <div className="text-sm text-slate-500">Order status and partner updates</div>
                </div>
              </div>
              <Switch checked={profile.pushNotifications} onCheckedChange={(value) => updateProfile({ pushNotifications: value })} />
            </div>
            <div className="flex items-center justify-between rounded-2xl border p-4">
              <div className="flex items-center gap-3">
                <Phone className="h-5 w-5 text-slate-400" />
                <div>
                  <div className="font-medium">SMS updates</div>
                  <div className="text-sm text-slate-500">Receive driver arrival messages</div>
                </div>
              </div>
              <Switch checked={profile.smsUpdates} onCheckedChange={(value) => updateProfile({ smsUpdates: value })} />
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-2 gap-2">
          <Button variant="outline" className="bg-white" onClick={resetProfile}>Reset profile</Button>
          <Link href="/profile">
            <Button className="w-full">
              <Save className="mr-2 h-4 w-4" />
              Done
            </Button>
          </Link>
        </div>
      </div>

      <div className="fixed bottom-0 left-0 right-0 mx-auto max-w-md border-t bg-white/95 backdrop-blur">
        <div className="grid grid-cols-4 py-2 text-xs">
          <Link href="/" className="flex flex-col items-center gap-1 p-2 text-slate-500"><Package className="h-5 w-5" />Order</Link>
          <Link href="/orders" className="flex flex-col items-center gap-1 p-2 text-slate-500"><Clock className="h-5 w-5" />Orders</Link>
          <Link href="/delivery" className="flex flex-col items-center gap-1 p-2 text-slate-500"><Truck className="h-5 w-5" />Deliver</Link>
          <Link href="/profile" className="flex flex-col items-center gap-1 p-2 font-medium text-blue-600"><User className="h-5 w-5" />Profile</Link>
        </div>
      </div>
    </div>
  )
}
