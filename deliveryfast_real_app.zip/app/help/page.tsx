"use client"

import Link from "next/link"
import { ArrowLeft, Clock, HelpCircle, Mail, MessageCircle, Package, Phone, ShieldCheck, Truck, User } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

const faqs = [
  {
    question: "How does the order flow work?",
    answer: "Create a quote, confirm the order, then a delivery partner can accept it from the Deliver tab. The order timeline updates automatically in My Orders.",
  },
  {
    question: "Is this connected to a real backend?",
    answer: "This version uses localStorage so it behaves like a real app on one device. It is ready to connect to Firebase, Supabase, or your own API later.",
  },
  {
    question: "Can partners navigate to customers?",
    answer: "Yes. The Navigate button opens a Google Maps route using the pickup and delivery addresses.",
  },
  {
    question: "Can I edit my profile?",
    answer: "Yes. Open Settings from the Profile tab and update your name, phone, email, city, payment method, and notifications.",
  },
]

export default function HelpPage() {
  return (
    <div className="min-h-screen bg-slate-50 pb-24">
      <header className="sticky top-0 z-50 border-b bg-white">
        <div className="flex items-center gap-4 p-4">
          <Link href="/profile">
            <Button variant="ghost" size="icon" aria-label="Back to profile">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
          <div>
            <h1 className="text-xl font-bold">Help & Support</h1>
            <p className="text-xs text-slate-500">Support center for Deliveryfast</p>
          </div>
        </div>
      </header>

      <div className="space-y-4 p-4">
        <Card className="border-blue-200 bg-blue-50 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-start gap-3">
              <ShieldCheck className="mt-1 h-6 w-6 text-blue-600" />
              <div>
                <h2 className="font-bold text-blue-950">Need urgent help?</h2>
                <p className="mt-1 text-sm text-blue-800">Contact support for order problems, partner questions, or payment issues.</p>
                <div className="mt-4 grid grid-cols-2 gap-2">
                  <Button onClick={() => (window.location.href = "tel:+212600000000")}>
                    <Phone className="mr-2 h-4 w-4" />
                    Call
                  </Button>
                  <Button variant="outline" className="bg-white" onClick={() => (window.location.href = "mailto:support@deliveryfast.app")}> 
                    <Mail className="mr-2 h-4 w-4" />
                    Email
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="shadow-sm">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <HelpCircle className="h-5 w-5" />
              Frequently Asked Questions
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {faqs.map((faq) => (
              <div key={faq.question} className="rounded-2xl border p-4">
                <div className="font-semibold">{faq.question}</div>
                <p className="mt-2 text-sm text-slate-600">{faq.answer}</p>
              </div>
            ))}
          </CardContent>
        </Card>

        <Card className="shadow-sm">
          <CardHeader>
            <CardTitle className="text-base">App capabilities added</CardTitle>
          </CardHeader>
          <CardContent className="flex flex-wrap gap-2">
            <Badge variant="secondary">Saved orders</Badge>
            <Badge variant="secondary">Map selection</Badge>
            <Badge variant="secondary">Partner acceptance</Badge>
            <Badge variant="secondary">Status timeline</Badge>
            <Badge variant="secondary">Profile settings</Badge>
            <Badge variant="secondary">Call / SMS actions</Badge>
          </CardContent>
        </Card>

        <Button variant="outline" className="w-full bg-white" onClick={() => (window.location.href = "sms:+212600000000?body=Hello Deliveryfast support,")}> 
          <MessageCircle className="mr-2 h-4 w-4" />
          Send support message
        </Button>
      </div>

      <div className="fixed bottom-0 left-0 right-0 mx-auto max-w-md border-t bg-white/95 backdrop-blur">
        <div className="grid grid-cols-4 py-2 text-xs">
          <Link href="/" className="flex flex-col items-center gap-1 p-2 text-slate-500"><Package className="h-5 w-5" />Order</Link>
          <Link href="/orders" className="flex flex-col items-center gap-1 p-2 text-slate-500"><Clock className="h-5 w-5" />Orders</Link>
          <Link href="/delivery" className="flex flex-col items-center gap-1 p-2 text-slate-500"><Truck className="h-5 w-5" />Deliver</Link>
          <Link href="/profile" className="flex flex-col items-center gap-1 p-2 font-medium text-blue-600"><User className="h-5 w-5" />Profile</Link>
        </div>
      </div>
    </div>
  )
}
