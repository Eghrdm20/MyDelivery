"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, Clock, HelpCircle, LogOut, Mail, MapPin, Package, Phone, Settings, ShieldCheck, Star, Truck, User } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import { useOrders, useOrderStats, useProfile } from "@/hooks/useOrders"

export default function ProfilePage() {
  const { orders, isLoaded, resetDemoData, clearOrders } = useOrders()
  const { profile } = useProfile()
  const stats = useOrderStats(orders)
  const [signedOut, setSignedOut] = useState(false)

  if (!isLoaded) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-slate-50">
        <div className="text-center">
          <div className="mx-auto mb-4 h-12 w-12 animate-spin rounded-full border-b-2 border-blue-600"></div>
          <p className="text-slate-600">Loading profile...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-slate-50 pb-24">
      <header className="sticky top-0 z-50 border-b bg-white">
        <div className="flex items-center gap-4 p-4">
          <Link href="/">
            <Button variant="ghost" size="icon" aria-label="Back home">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
          <div>
            <h1 className="text-xl font-bold">Profile</h1>
            <p className="text-xs text-slate-500">Account, stats, and support</p>
          </div>
        </div>
      </header>

      {signedOut && (
        <div className="px-4 pt-4">
          <Card className="border-blue-200 bg-blue-50">
            <CardContent className="p-4 text-sm text-blue-800">Local demo session cleared. Your saved profile and demo orders are still available.</CardContent>
          </Card>
        </div>
      )}

      <div className="p-4">
        <Card className="shadow-sm">
          <CardContent className="flex items-center gap-4 p-6">
            <Avatar className="h-16 w-16">
              <AvatarImage src="/placeholder-user.jpg" alt="Profile" />
              <AvatarFallback className="bg-blue-100 text-lg font-bold text-blue-600">
                {profile.name
                  .split(" ")
                  .map((part) => part[0])
                  .slice(0, 2)
                  .join("")}
              </AvatarFallback>
            </Avatar>
            <div className="min-w-0 flex-1">
              <h2 className="truncate text-2xl font-black">{profile.name}</h2>
              <p className="text-slate-600">Member since {profile.memberSince}</p>
              <div className="mt-2 flex flex-wrap items-center gap-2">
                <Badge variant="secondary" className="gap-1">
                  <Star className="h-3 w-3 fill-yellow-500 text-yellow-500" />
                  {profile.rating}
                </Badge>
                {profile.verified && (
                  <Badge variant="outline" className="gap-1">
                    <ShieldCheck className="h-3 w-3" />
                    Verified
                  </Badge>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="px-4 pb-4">
        <Card className="shadow-sm">
          <CardHeader>
            <CardTitle className="text-base">Contact Information</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <button onClick={() => (window.location.href = `tel:${profile.phone}`)} className="flex w-full items-center gap-3 text-left">
              <Phone className="h-4 w-4 text-slate-400" />
              <span className="text-sm">{profile.phone}</span>
            </button>
            <button onClick={() => (window.location.href = `mailto:${profile.email}`)} className="flex w-full items-center gap-3 text-left">
              <Mail className="h-4 w-4 text-slate-400" />
              <span className="text-sm">{profile.email}</span>
            </button>
            <div className="flex items-center gap-3">
              <MapPin className="h-4 w-4 text-slate-400" />
              <span className="text-sm">{profile.city}</span>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="px-4 pb-4">
        <Card className="shadow-sm">
          <CardHeader>
            <CardTitle className="text-base">Statistics</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4">
              <div className="rounded-2xl bg-blue-50 p-4 text-center">
                <Package className="mx-auto mb-2 h-7 w-7 text-blue-600" />
                <div className="text-3xl font-black text-blue-600">{stats.totalOrders}</div>
                <div className="text-xs text-slate-600">Orders Placed</div>
              </div>
              <div className="rounded-2xl bg-green-50 p-4 text-center">
                <Truck className="mx-auto mb-2 h-7 w-7 text-green-600" />
                <div className="text-3xl font-black text-green-600">{stats.deliveredCount}</div>
                <div className="text-xs text-slate-600">Deliveries Done</div>
              </div>
            </div>
            <div className="mt-4 rounded-2xl bg-amber-50 p-4 text-center">
              <div className="text-3xl font-black text-amber-600">{stats.totalSpent} MAD</div>
              <div className="text-sm text-slate-600">Total Delivery Value</div>
            </div>
            <div className="mt-3 grid grid-cols-2 gap-3 text-center text-sm">
              <div className="rounded-xl bg-slate-50 p-3">
                <div className="font-bold">{stats.activeCount}</div>
                <div className="text-slate-500">Active</div>
              </div>
              <div className="rounded-xl bg-slate-50 p-3">
                <div className="font-bold">{stats.averageOrderValue} MAD</div>
                <div className="text-slate-500">Average</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="px-4 pb-4">
        <Card className="shadow-sm">
          <CardContent className="divide-y p-0">
            <Link href="/settings" className="flex items-center justify-between p-4 hover:bg-slate-50">
              <div className="flex items-center gap-3">
                <Settings className="h-5 w-5 text-slate-400" />
                <span>Settings</span>
              </div>
              <span className="text-slate-400">›</span>
            </Link>
            <Link href="/help" className="flex items-center justify-between p-4 hover:bg-slate-50">
              <div className="flex items-center gap-3">
                <HelpCircle className="h-5 w-5 text-slate-400" />
                <span>Help & Support</span>
              </div>
              <span className="text-slate-400">›</span>
            </Link>
            <button onClick={resetDemoData} className="flex w-full items-center justify-between p-4 text-left hover:bg-slate-50">
              <div className="flex items-center gap-3">
                <Package className="h-5 w-5 text-slate-400" />
                <span>Restore demo orders</span>
              </div>
              <span className="text-slate-400">›</span>
            </button>
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <button className="flex w-full items-center justify-between p-4 text-left text-red-600 hover:bg-red-50">
                  <div className="flex items-center gap-3">
                    <LogOut className="h-5 w-5" />
                    <span>Sign Out / Clear orders</span>
                  </div>
                  <span className="text-slate-400">›</span>
                </button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogTitle>Clear local orders?</AlertDialogTitle>
                <AlertDialogDescription>This only clears the demo data stored on this device. It does not delete any backend account.</AlertDialogDescription>
                <div className="flex justify-end gap-2">
                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                  <AlertDialogAction
                    className="bg-red-600 hover:bg-red-700"
                    onClick={() => {
                      clearOrders()
                      setSignedOut(true)
                    }}
                  >
                    Clear orders
                  </AlertDialogAction>
                </div>
              </AlertDialogContent>
            </AlertDialog>
          </CardContent>
        </Card>
      </div>

      <div className="px-4 pt-2 text-center text-sm text-slate-500">
        <p className="font-medium">Deliveryfast v1.1.0</p>
        <p>Quick local delivery in your city</p>
      </div>

      <div className="fixed bottom-0 left-0 right-0 mx-auto max-w-md border-t bg-white/95 backdrop-blur">
        <div className="grid grid-cols-4 py-2 text-xs">
          <Link href="/" className="flex flex-col items-center gap-1 p-2 text-slate-500">
            <Package className="h-5 w-5" />
            Order
          </Link>
          <Link href="/orders" className="flex flex-col items-center gap-1 p-2 text-slate-500">
            <Clock className="h-5 w-5" />
            Orders
          </Link>
          <Link href="/delivery" className="flex flex-col items-center gap-1 p-2 text-slate-500">
            <Truck className="h-5 w-5" />
            Deliver
          </Link>
          <Link href="/profile" className="flex flex-col items-center gap-1 p-2 font-medium text-blue-600">
            <User className="h-5 w-5" />
            Profile
          </Link>
        </div>
      </div>
    </div>
  )
}
